from flask_app import app
from flask import render_template, redirect, request, session
from flask_app.models.band import Band
from flask_app.models.user import User

@app.route('/dashboard')
def dashboard():
    if 'user_id' not in session:
        return redirect('/user/login')
    user = User.get_id({"id":session['user_id']})
    if not user:
        return redirect('/user/logout')
    return render_template('dashboard.html', user=user, bands=Band.get_all_bands())

@app.route('/new/sighting')
def create_band():
    if 'user_id' not in session:
        return redirect('/user/login')
    user = User.get_id({"id":session['user_id']})
    if not user:
        return redirect('/user/logout')
    return render_template('new_band.html', user=user)

@app.route('/bands/new/process', methods=['POST'])
def process_band():
    if 'user_id' not in session:
        return redirect('/')
    if not Band.validate_band(request.form):
        return redirect('/new/sighting')
    data = {
        'user_id': session['user_id'],
        'name': request.form['name'],
        'genre': request.form['genre'],
        'home_city': request.form['home_city'],
    }
    Band.save(data)
    return redirect('/dashboard')

@app.route('/bands/edit/<int:id>')
def edit_band(id):
    if 'user_id' not in session:
        return redirect('/user/login')
    user = User.get_id({"id":session['user_id']})
    if not user:
        return redirect('/user/logout')
    data = {
        'id':id
        }
    return render_template('edit_bands.html', user=user, band=Band.get_id(data))

@app.route('/band/edit/process/<int:id>', methods=['POST'])
def process_edit(id):
    if 'user_id' not in session:
        return redirect('/user/login')
    if not Band.validate_band(request.form):
        return redirect(f'/bands/edit/{id}')
    data = {
        'id': id,
        'name': request.form['name'],
        'genre': request.form['genre'],
        'home_city': request.form['home_city'],
    }
    Band.update(data)
    return redirect('/dashboard')

@app.route('/bands/destroy/<int:id>')
def destroy_band(id):
    if 'user_id' not in session:
        return redirect('/user/login')
    Band.destroy({'id':id})
    return redirect('/dashboard')

@app.route('/user/bands')
def user_bands():
        if 'user_id' not in session:
            return redirect('/user/login')
        user = User.get_id({"id":session['user_id']})
        if not user:
            return redirect('/user/logout')
        bands = Band.get_all_bands()
        return render_template('my_bands.html', user=user, bands=bands)
