from flask_app.config.mysqlconnection import connectToMySQL
from flask_app.models import user
from flask import flash

class Band:
    db = "band_together"
    def __init__(self, db_data):
        self.id = db_data['id']
        self.name = db_data['name']
        self.genre = db_data['genre']
        self.home_city = db_data['home_city']
        self.created_at = db_data['created_at']
        self.updated_at = db_data['updated_at']
        self.user_id = db_data['user_id']
        self.founder = None

    @classmethod
    def get_all_bands(cls):
        query = """
                SELECT * FROM bands
                LEFT JOIN users on bands.user_id = users.id;
                """
        results = connectToMySQL(cls.db).query_db(query)
        bands = []
        for row in results:
            this_band = cls(row)
            user_data = {
                "id": row['users.id'],
                "first_name": row['first_name'],
                "last_name": row['last_name'],
                "email": row['email'],
                "password": "",
                "created_at": row['users.created_at'],
                "updated_at": row['users.updated_at']
            }
            this_band.founder = user.User(user_data)
            bands.append(this_band)
        return bands

    @classmethod
    def get_id(cls, data):
        query = """
                SELECT * FROM bands
                JOIN users on bands.user_id = users.id
                WHERE bands.id = %(id)s;
                """
        result = connectToMySQL(cls.db).query_db(query, data)
        if not result:
            return False
        result = result[0]
        this_band = cls(result)
        user_data = {
            "id": result['users.id'],
            "first_name": result['first_name'],
            "last_name": result['last_name'],
            "email": result['email'],
            "password": "",
            "created_at": result['users.created_at'],
            "updated_at": result['users.updated_at']
        }
        this_band.founder = user.User(user_data)
        return this_band

    @classmethod
    def save(cls, form_data):
        query = """
                INSERT INTO bands (name, genre, home_city, user_id)
                VALUES (%(name)s, %(genre)s, %(home_city)s, %(user_id)s);
                """
        return connectToMySQL(cls.db).query_db(query, form_data)

    @classmethod
    def update(cls, form_data):
        query = """
                UPDATE bands
                SET name = %(name)s,
                genre = %(genre)s,
                home_city = %(home_city)s
                WHERE id = %(id)s;
                """
        return connectToMySQL(cls.db).query_db(query,form_data)

    @classmethod
    def destroy(cls, data):
        query = """
                DELETE FROM bands
                WHERE id = %(id)s;
                """
        return connectToMySQL(cls.db).query_db(query, data)

    @staticmethod
    def validate_band(form_data):
        is_valid = True
        if len(form_data['name']) < 2:
            flash("Band name must be a least 2 characters long!", "create_band")
            is_valid = False
        if len(form_data['genre']) < 2:
            flash("Genre needs to be at least 2 characters long!", "create_band")
            is_valid = False
        return is_valid
