from flask_app.config.mysqlconnection import connectToMySQL
from flask import flash
from flask_app import bcrypt
import re
EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')

class User:
    db = 'band_together'
    def __init__(self, db_data):
        self.id=db_data['id']
        self.first_name=db_data['first_name']
        self.last_name=db_data['last_name']
        self.email=db_data['email']
        self.password=db_data['password']
        self.created_at = db_data['created_at']
        self.updated_at=db_data['updated_at']

    @classmethod
    def save(cls, form_data):
        query = """INSERT INTO users (first_name, last_name, email, password)
                    VALUES (%(first_name)s, %(last_name)s, %(email)s, %(password)s);"""
        return connectToMySQL(cls.db).query_db(query, form_data)

    @classmethod
    def get_email(cls, data):
        query = """
                SELECT * FROM users
                WHERE email = %(email)s;
                """
        results = connectToMySQL(cls.db).query_db(query,data)
        if not results:
            return False
        return cls(results[0])

    
    @classmethod
    def get_id(cls, data):
        query = """SELECT * FROM users
                    WHERE id = %(id)s;"""
        results = connectToMySQL(cls.db).query_db(query,data)
        if not results:
            return False
        return cls(results[0])

    @staticmethod
    def validate_user(form_data):
        is_valid = True
        query = """SELECT * FROM users
                    WHERE email = %(email)s"""
        results = connectToMySQL(User.db).query_db(query, form_data)
        if len(form_data['password']) < 8:
            flash("Password must be a least 8 characters.", "register")
            is_valid = False
        if len(form_data['first_name']) < 2:
            flash("First name must be at least 2 characters long", "register")
            is_valid = False
        if len(form_data['last_name']) < 2:
            flash("Last name must be at least 2 characters long", "register")
            is_valid = False
        if form_data['password'] != form_data['confirm']:
            flash("Passwords don't match", "register")
            is_valid = False
        if not EMAIL_REGEX.match(form_data['email']):
            flash('Invalid Email', "register")
            is_valid = False
        if User.get_email(form_data):
            flash('Email already in use', 'register')
            is_valid = False
        if len(form_data['email']) < 1:
            flash("Email Required", "register")
            is_valid = False
        return is_valid

    @staticmethod
    def validate_login(form_data):
        if not EMAIL_REGEX.match(form_data['email']):
            flash("Invalid email/password.", "login")
            return False
        user = User.get_email(form_data)
        if not user:
            flash("Invalid email/password.", "login")
            return False
        if not bcrypt.check_password_hash(user.password, form_data['password']):
            flash("Invalid email/password.","login")
            return False
        return user

    
    def full_name(self):
        return f'{self.first_name} {self.last_name}'