from flask_app import app
from flask import render_template, redirect, request, session
from flask_app.models.skill import Skill
from flask_app.models.user import User

@app.route('/dashboard')
def dashboard():
    if 'user_id' not in session:
        return redirect('/user/login')
    user = User.get_id({"id":session['user_id']})
    if not user:
        return redirect('/user/logout')
    user_skills = Skill.get_user_skills({'user_id': session['user_id']})
    all_skills = Skill.get_all_skills()
    return render_template('dashboard.html', user=user, user_skills=user_skills, all_skills=all_skills)


@app.route('/new/skill')
def add_skill():
    if 'user_id' not in session:
        return redirect('/user/login')
    user = User.get_id({"id":session['user_id']})
    if not user:
        return redirect('/user/logout')
    skills = Skill.get_all_skills()
    return render_template('new_skill.html', user=user, skills=skills)



@app.route('/skills/new/process', methods=['POST'])
def process_skill():
    if 'user_id' not in session:
        return redirect('/')
    if 'method' in request.form and request.form['method'] == 'select':
        data = {
            'user_id': session['user_id'],
            'name': request.form['name'],
            'description': request.form['description'],
        }
    else:
        data = {
            'user_id': session['user_id'],
            'name': request.form['name'],
            'description': '',
        }
    if not Skill.validate_skill(request.form):
        return redirect('/new/skill')
    data = {
        'user_id': session['user_id'],
        'name': request.form['name'],
        'description': request.form.get('description', '')
    }
    Skill.save(data)
    return redirect('/dashboard')

@app.route("/skills/new/process/select", methods=['POST'])
def select_skill():
    if 'user_id' not in session:
        return redirect('/')
    if 'method' in request.form and request.form['method'] == 'form':
        skill_id = int(request.form['skill'])
        skill_name = Skill.get_skill_name_by_id(skill_id)
        data = {
            'user_id': session['user_id'],
            'name': skill_name,
            'description': '',
            'skill_id': skill_id,
        }
    if not Skill.validate_skill(request.form):
        return redirect('/new/skill')
    data = {
        'user_id': session['user_id'],
        'description': request.form.get('description', ''),
        'name': request.form.get('name', ''),
    }
    Skill.save(data)
    return redirect('/dashboard')



@app.route('/skills/edit/<int:id>')
def edit_skill(id):
    if 'user_id' not in session:
        return redirect('/user/login')
    user = User.get_id({"id":session['user_id']})
    if not user:
        return redirect('/user/logout')
    skills = Skill.get_all_skills()
    return render_template('update_skill.html', user=user, skill=Skill.get_id({'id':id}), skills=skills)

@app.route('/skills/edit/process/<int:id>', methods=['POST'])
def process_edit(id):
    if 'user_id' not in session:
        return redirect('/')
    if 'method' in request.form and request.form['method'] == 'form':
        data = {
            'id':id,
            'user_id': session['user_id'],
            'name': request.form['name'],
            'description': request.form['description'],
        }
    else:
        data = {
            'id':id,
        'user_id': session['user_id'],
        'description': request.form.get('description', ''),
        'name': request.form.get('name', ''),
        }
    Skill.update(data)
    return redirect('/dashboard')

@app.route("/skills/edit/process/select/<int:id>", methods=['POST'])
def update_select_skill(id):
    if 'user_id' not in session:
        return redirect('/')
    if 'method' in request.form and request.form['method'] == 'select':
        skill_id = int(request.form['skill'])
        skill_name = Skill.get_skill_name_by_id(skill_id)
        data = {
            'id':id,
            'user_id': session['user_id'],
            'name': skill_name,
            'description': '',
            'skill_id': skill_id,
        }
    if not Skill.validate_skill(request.form):
        return redirect('/new/skill')
    data = {
        'id':id,
        'user_id': session['user_id'],
        'description': request.form.get('description', ''),
        'name': request.form.get('name', ''),
    }
    Skill.update(data)
    return redirect('/dashboard')

@app.route('/skills/destroy/<int:id>')
def destroy_skill(id):
    if 'user_id' not in session:
        return redirect('/user/login')
    Skill.destroy({'id':id})
    return redirect('/dashboard')

@app.route('/skill/<int:skill_id>/users')
def skill_users(skill_id):
    if 'user_id' not in session:
        return redirect('/user/login')
    user = User.get_id({"id":session['user_id']})
    if not user:
        return redirect('/user/logout')
    users = User.get_users_by_skill_id(skill_id)
    user_skills = Skill.get_user_skills({'user_id': session['user_id']})
    all_skills = Skill.get_all_skills()
    skill_name = Skill.get_skill_name_by_id({'id': skill_id})
    return render_template('skill_page.html', user=user, users=users, user_skills=user_skills, all_skills=all_skills, skill_name=skill_name)

#@app.route('/skill/<int:skill_id>/users')
#def skill_users(skill_id):
#    if 'user_id' not in session:
#        return redirect('/user/login')
#    user = User.get_id({"id": session['user_id']})
#    if not user:
#        return redirect('/user/logout')
#    users = User.get_users_by_skill_id(skill_id)
#    skill_name = Skill.get_skill_name_by_id({'id': skill_id})
#    return render_template('skill_page.html', users=users, skill_name=skill_name)