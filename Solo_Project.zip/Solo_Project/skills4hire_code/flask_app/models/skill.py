from flask_app.config.mysqlconnection import connectToMySQL
from flask_app.models import user
from flask import flash

class Skill:
    db = "skills4hire"
    def __init__(self, db_data):
        self.id = db_data['id']
        self.name = db_data['name']
        self.description = db_data['description']
        self.created_at = db_data['created_at']
        self.updated_at = db_data['updated_at']
        self.user_id = db_data['user_id']
        self.hire = None

    @classmethod
    def get_all_skills(cls):
        query = """
                SELECT * FROM skills
                LEFT JOIN users on skills.user_id = users.id;
                """
        results = connectToMySQL(cls.db).query_db(query)
        skills = []
        for row in results:
            this_skill = cls(row)
            user_data = {
                "id": row['users.id'],
                "first_name": row['first_name'],
                "last_name": row['last_name'],
                "email": row['email'],
                "password": "",
                "created_at": row['users.created_at'],
                "updated_at": row['users.updated_at']
            }
            this_skill.hire = user.User(user_data)
            skills.append(cls(row))
        return skills


    @classmethod
    def get_user_skills(cls, data):
        query = "SELECT * FROM skills JOIN users_skills ON skills.id = users_skills.skill_id WHERE users_skills.user_id = %(user_id)s;"
        results = connectToMySQL(cls.db).query_db(query, data)
        skills = []
        if results:
            for item in results:
                skills.append(cls(item))
        return skills

    @classmethod
    def get_id(cls, data):
        query = """
                SELECT * FROM skills
                JOIN users on skills.user_id = users.id
                WHERE skills.id = %(id)s;
                """
        result = connectToMySQL(cls.db).query_db(query, data)
        if not result:
            return False
        result = result[0]
        this_skill = cls(result)
        user_data = {
            "id": result['users.id'],
            "first_name": result['first_name'],
            "last_name": result['last_name'],
            "email": result['email'],
            "password": "",
            "created_at": result['users.created_at'],
            "updated_at": result['users.updated_at']
        }
        this_skill.hire = User(user_data)
        return this_skill

    @classmethod
    def get_skill_name_by_id(cls, data):
        query = "SELECT name FROM skills WHERE id = %(id)s"
        result = connectToMySQL(cls.db).query_db(query, data)
        if not result:
            return None
        return result[0]['name']

    @classmethod
    def get_skills_by_user_id(cls, user_id):
        query = '''
            SELECT skills.* FROM skills
            JOIN users_skills ON users_skills.skill_id = skills.id
            WHERE users_skills.user_id = %(user_id)s
        '''
        data = {'user_id': user_id}
        results = connectToMySQL(cls.db).query_db(query, data)
        if not results:
            return []
        skills = []
        for row in results:
            skills.append({
                'id': row['id'],
                'name': row['name']
            })
        return skills

    @classmethod
    def save(cls, form_data):
        query = """
                INSERT INTO skills (name, description, user_id)
                VALUES (%(name)s, %(description)s, %(user_id)s);
                """
        return connectToMySQL(cls.db).query_db(query, form_data)

    @classmethod
    def get_skill(cls, skill_id):
        query = "SELECT * FROM skills WHERE id = %(skill_id)s"
        data = {"skill_id": skill_id}
        result = connectToMySQL(cls.db).query_db(query, data)
        if len(result) < 1:
            return False
        return cls(result[0])

    @classmethod
    def update(cls, form_data):
        query = """
                UPDATE skills
                SET name = %(name)s,
                description = %(description)s
                WHERE id = %(id)s;
                """
        return connectToMySQL(cls.db).query_db(query,form_data)

    @classmethod
    def destroy(cls, data):
        query = """
                DELETE FROM skills
                WHERE id = %(id)s;
                """
        return connectToMySQL(cls.db).query_db(query, data)

    @staticmethod
    def validate_skill(form_data):
        is_valid = True
        if len(form_data['name']) < 2:
            flash("Please include a name for the skill", "create_skill")
            is_valid = False
        if len(form_data['description']) < 2:
            flash("Please provide a description for the skill", "create_skill")
            is_valid = False
        return is_valid



