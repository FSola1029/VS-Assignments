from flask_app.config.mysqlconnection import connectToMySQL
from flask_app.models import user
from flask import flash

class Pie:
    db = "pypie_derby_retry"
    def __init__(self, db_data):
        self.id = db_data['id']
        self.name = db_data['name']
        self.filling = db_data['filling']
        self.crust = db_data['crust']
        self.created_at = db_data['created_at']
        self.updated_at = db_data['updated_at']
        self.user_id = db_data['user_id']
        self.votes = db_data['votes']
        self.creator = None

    @classmethod
    def get_all_for_one(cls):
        query = "SELECT * FROM pies"
        results = connectToMySQL(cls.db).query_db(query)
        user_pies = []
        for p in results:
            user_pies.append(cls(p))
        return user_pies

    @classmethod
    def get_all(cls):
        query = """
                SELECT * FROM pies
                LEFT JOIN users on pies.user_id = users.id;
                """
        results = connectToMySQL(cls.db).query_db(query)
        pies = []
        for row in results:
            this_pie = cls(row)
            user_data = {
                "id": row['users.id'],
                "first_name": row['first_name'],
                "last_name": row['last_name'],
                "email": row['email'],
                "password": "",
                "created_at": row['users.created_at'],
                "updated_at": row['users.updated_at']
            }
            this_pie.creator = user.User(user_data)
            pies.append(this_pie)
        return pies


    @classmethod
    def get_id(cls, data):
        query = """
                SELECT * FROM pies
                JOIN users on pies.user_id = users.id
                WHERE pies.id = %(id)s;
                """
        result = connectToMySQL(cls.db).query_db(query, data)
        if not result:
            return False
        result = result[0]
        this_pie = cls(result)
        user_data = {
            "id": result['users.id'],
            "first_name": result['first_name'],
            "last_name": result['last_name'],
            "email": result['email'],
            "password": "",
            "created_at": result['users.created_at'],
            "updated_at": result['users.updated_at']
        }
        this_pie.creator = user.User(user_data)
        return this_pie

    @classmethod
    def get_all_in_derby(cls):
        query = """
                SELECT * FROM pies
                JOIN users on pies.user_id = users.id
                ORDER BY votes DESC;
                """
        results = connectToMySQL(cls.db).query_db(query)
        pies = []
        for row in results:
            this_pie = cls(row)
            user_data = {
                "id": row['users.id'],
                "first_name": row['first_name'],
                "last_name": row['last_name'],
                "email": row['email'],
                "password": "",
                "created_at": row['users.created_at'],
                "updated_at": row['users.updated_at']
            }
            this_pie.creator = user.User(user_data)
            pies.append(this_pie)
        return pies

    @classmethod
    def save(cls, form_data):
        query = """
                INSERT INTO pies (name, filling, crust, user_id)
                VALUES (%(name)s, %(filling)s, %(crust)s, %(user_id)s);
                """
        return connectToMySQL(cls.db).query_db(query, form_data)

    @classmethod
    def update(cls, form_data):
        query = """
                UPDATE pies
                SET name = %(name)s,
                filling = %(filling)s,
                crust = %(crust)s
                WHERE id = %(id)s;
                """
        return connectToMySQL(cls.db).query_db(query,form_data)

    @classmethod
    def set_value(cls,data):
        query = """
                UPDATE pies
                SET votes = 0
                WHERE votes is null;
                """
        return connectToMySQL(cls.db).query_db(query, data)

    @classmethod
    def destroy(cls, data):
        query = """
                DELETE FROM pies
                WHERE id = %(id)s;
                """
        return connectToMySQL(cls.db).query_db(query, data)

    @classmethod
    def vote(cls, data):
        query = """
                UPDATE pies
                SET votes = votes + 1
                WHERE id = %(id)s; 
                """
        return connectToMySQL(cls.db).query_db(query, data)

    @classmethod
    def yuck(cls, data):
        query = """
                UPDATE pies
                SET votes = votes - 1
                WHERE id = %(id)s; 
                """
        return connectToMySQL(cls.db).query_db(query, data)

    @staticmethod
    def validate_pie(form_data):
        is_valid = True
        if len(form_data['name']) < 1:
            flash("Please name your pie!", "create_pie")
            is_valid = False
        if len(form_data['filling']) < 1:
            flash("Pie needs a filling!", "create_pie")
            is_valid = False
        if len(form_data['crust']) < 1:
            flash("Pie needs a crust!", "create_pie")
            is_valid = False
        return is_valid
