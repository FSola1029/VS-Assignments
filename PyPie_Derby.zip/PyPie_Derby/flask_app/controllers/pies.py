from flask_app import app
from flask import render_template, redirect, request, session
from flask_app.models.pie import Pie
from flask_app.models.user import User

@app.route('/dashboard')
def dashboard():
    if 'user_id' not in session:
        return redirect('/user/login')
    user = User.get_id({"id":session['user_id']})
    if not user:
        return redirect('/user/logout')
    return render_template('dashboard.html', user=user, pies=Pie.get_all())


@app.route('/pie/new', methods=['POST'])
def process_pie():
    if 'user_id' not in session:
        return redirect('/')
    if not Pie.validate_pie(request.form):
        return redirect('/dashboard')
    data = {
        'user_id': session['user_id'],
        'name': request.form['name'],
        'filling': request.form['filling'],
        'crust': request.form['crust'],
    }
    Pie.save(data)
    Pie.set_value(data)
    return redirect('/dashboard')

@app.route('/pie/<int:id>')
def view_pie(id):
    if 'user_id' not in session:
        return redirect('/user/login')
    data = {
        'id':id
        }
    return render_template('pie_details.html', pie=Pie.get_id(data))

@app.route('/pies/edit/<int:id>')
def edit_pie(id):
    if 'user_id' not in session:
        return redirect('/user/login')
    data = {
        'id':id
        }
    return render_template('edit_pies.html', pie=Pie.get_id(data))

@app.route('/pie/edit/process/<int:id>', methods=['POST'])
def process_edit(id):
    if 'user_id' not in session:
        return redirect('/user/login')
    if not Pie.validate_pie(request.form):
        return redirect(f'/pies/edit/{id}')
    data = {
        'id': id,
        'name': request.form['name'],
        'filling': request.form['filling'],
        'crust': request.form['crust'],
    }
    Pie.update(data)
    return redirect('/pies/derby')

@app.route('/pies/destroy/<int:id>')
def destroy_pie(id):
    if 'user_id' not in session:
        return redirect('/user/login')
    Pie.destroy({'id':id})
    return redirect('/dashboard')

@app.route('/pie/vote/<int:id>', methods=['POST'])
def vote_pie(id):
    if 'user_id' not in session:
        return redirect('/user/login')
    data = {
        'id':id
    }
    Pie.vote(data)
    return redirect('/dashboard')
    
@app.route('/pies/derby')
def derby():
    if 'user_id' not in session:
        return redirect('/user/login')
    user = User.get_id({'id':session['user_id']})
    if not user:
        return redirect('/user/logout')
    return render_template('pies.html', user=user, pies=Pie.get_all_in_derby())