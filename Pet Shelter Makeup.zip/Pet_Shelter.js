function hide(element){
    element.remove();
}

function addOne(id){
    var element = document.querySelector("#"+id);
    element.innerText++;
}

function select(){
    var pet = document.getElementById('pet').value;
    alert('You are looking for ' + pet)
}